package ro.ase.semdam_1087;

import android.os.AsyncTask;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class ExtractXML extends AsyncTask<URL, Void, InputStream> {

    InputStream ist = null;
    public List<Masina> masinaList;

    @Override
    protected InputStream doInBackground(URL... urls) {

        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection)urls[0].openConnection();
            connection.setRequestMethod("GET");
            ist = connection.getInputStream();

            //var1 - parsare XML
            masinaList = parsareXML(ist);

            //var2 - conversie String
            /*InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);
            String linie = null;
            while ((linie = br.readLine())!=null)
                rezultat+=linie;*/

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return null;
    }

    public static Node getNodeByName(String nodeName, Node parentNode) throws Exception {

        if (parentNode.getNodeName().equals(nodeName)) {
            return parentNode;
        }

        NodeList list = parentNode.getChildNodes();
        for (int i = 0; i < list.getLength(); i++)
        {
            Node node = getNodeByName(nodeName, list.item(i));
            if (node != null) {
                return node;
            }
        }
        return null;
    }

    public static String getAttributeValue(Node node, String attrName) {
        try {
            return ((Element)node).getAttribute(attrName);
        }
        catch (Exception e) {
            return "";
        }
    }
    public List<Masina> parsareXML(InputStream ist)
    {
        List<Masina> list = new ArrayList<>();

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document domDoc = db.parse(ist);
            domDoc.getDocumentElement().normalize();

            Node cube = getNodeByName("Masini", domDoc.getDocumentElement());
            if(cube!=null)
            {
                NodeList listaCopii = cube.getChildNodes();
                for(int j=0;j<listaCopii.getLength();j++)
                {
                    Node copil = listaCopii.item(j);
                    if(copil!=null&&copil.getNodeName().equals("Masina"))
                    {
                        Masina masina = new Masina();

                        NodeList taguri = copil.getChildNodes();
                        for(int i=0;i<taguri.getLength();i++)
                        {
                            Node node= taguri.item(i);
                            String atribut = getAttributeValue(node, "atribut");
                            if(atribut.equals("Marca"))
                                masina.setMarca(node.getTextContent());
                            else
                                if(atribut.equals("DataFabricatiei"))
                                    masina.setDataFabricatiei(new Date(node.getTextContent()));
                                else
                                    if(atribut.equals("Pret"))
                                        masina.setPret(Float.parseFloat(node.getTextContent()));
                                    else
                                        if(atribut.equals("Motorizare"))
                                            masina.setMotorizare(node.getTextContent());
                                        else
                                            if(atribut.equals("AreRCA"))
                                                masina.setAreRCA(Boolean.parseBoolean(node.getTextContent()));
                        }
                        list.add(masina);
                    }
                }
            }

        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
}
