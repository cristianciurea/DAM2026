package ro.ase.semdam_1087;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class ExtractJSON extends AsyncTask<URL, Void, String> {

    public List<Masina> masinaListJSON = new ArrayList<>();

    @Override
    protected String doInBackground(URL... urls) {

        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection)urls[0].openConnection();
            connection.setRequestMethod("GET");
            InputStream ist = connection.getInputStream();

            //var2 - conversie String
            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);
            String linie = null;
            String rezultat = "";
            while ((linie = br.readLine())!=null)
                rezultat+=linie;

            //parsare JSON
            parsareJSON(rezultat);

            return rezultat;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void parsareJSON(String jsonStr)
    {
        try {
            JSONObject jsonObject = new JSONObject(jsonStr);
            JSONArray vectMasini = jsonObject.getJSONArray("masini");
            for(int i=0;i<vectMasini.length();i++)
            {
                JSONObject obj = vectMasini.getJSONObject(i);

                String marca = obj.getString("Marca");
                Date dataFabricatiei = new Date(obj.getString("DataFabricatiei"));
                float pret = Float.parseFloat(obj.getString("Pret"));
                String motorizare = obj.getString("Motorizare");
                boolean areRCA = Boolean.parseBoolean(obj.getString("AreRCA"));

                Masina masina = new Masina(marca, dataFabricatiei, pret, motorizare, areRCA);
                masinaListJSON.add(masina);
            }

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}
