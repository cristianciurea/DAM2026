package ro.ase.semdam_1116;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String[] coduriCAEN = {"8510", "8520", "8531"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                coduriCAEN);
        Spinner spinner = findViewById(R.id.spinnerCoduriCAEN);
        spinner.setAdapter(adapter);

        EditText etDenumire = findViewById(R.id.editTextDenumire);
        EditText etData = findViewById(R.id.editTextDate);
        EditText etCifraAfaceri = findViewById(R.id.editTextCifraAfaceri);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        Button btnAdauga = findViewById(R.id.btnAdauga);
        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etDenumire.getText().toString().isEmpty())
                    etDenumire.setError("Introduceti denumirea!");
                else
                    if(etData.getText().toString().isEmpty())
                        etData.setError("Introduceti data!");
                    else
                        if(etCifraAfaceri.getText().toString().isEmpty())
                            etCifraAfaceri.setError("Introduceti CA!");
                        else
                        {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy",
                                    Locale.US);
                            try {
                                sdf.parse(etData.getText().toString());
                                String denumire = etDenumire.getText().toString();
                                Date dataInfiintarii = new Date(etData.getText().toString());
                                float cifraAfaceri = Float.parseFloat(etCifraAfaceri.getText().toString());
                                String codCAEN = spinner.getSelectedItem().toString();
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                boolean esteSuspendata = false;
                                if(radioButton.getText().equals("DA"))
                                    esteSuspendata = true;

                                Companie companie = new Companie(denumire, dataInfiintarii, cifraAfaceri, codCAEN, esteSuspendata);
                                Toast.makeText(getApplicationContext(), companie.toString(), Toast.LENGTH_LONG).show();

                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                            catch (Exception ex)
                            {
                                Toast.makeText(getApplicationContext(),
                                        ex.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }
}