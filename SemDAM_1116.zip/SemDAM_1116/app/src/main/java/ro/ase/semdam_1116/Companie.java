package ro.ase.semdam_1116;

import java.util.Date;

public class Companie {

    private String denumire;
    private Date dataInfiintarii;
    private float cifraAfaceri;
    private String codCAEN; //8510, 8520, 8531
    private boolean esteSuspendata; //DA - true, NU - false

    public Companie(String denumire, Date dataInfiintarii, float cifraAfaceri, String codCAEN, boolean esteSuspendata) {
        this.denumire = denumire;
        this.dataInfiintarii = dataInfiintarii;
        this.cifraAfaceri = cifraAfaceri;
        this.codCAEN = codCAEN;
        this.esteSuspendata = esteSuspendata;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public Date getDataInfiintarii() {
        return dataInfiintarii;
    }

    public void setDataInfiintarii(Date dataInfiintarii) {
        this.dataInfiintarii = dataInfiintarii;
    }

    public float getCifraAfaceri() {
        return cifraAfaceri;
    }

    public void setCifraAfaceri(float cifraAfaceri) {
        this.cifraAfaceri = cifraAfaceri;
    }

    public String getCodCAEN() {
        return codCAEN;
    }

    public void setCodCAEN(String codCAEN) {
        this.codCAEN = codCAEN;
    }

    public boolean isEsteSuspendata() {
        return esteSuspendata;
    }

    public void setEsteSuspendata(boolean esteSuspendata) {
        this.esteSuspendata = esteSuspendata;
    }

    @Override
    public String toString() {
        return "Companie{" +
                "denumire='" + denumire + '\'' +
                ", dataInfiintarii=" + dataInfiintarii +
                ", cifraAfaceri=" + cifraAfaceri +
                ", codCAEN='" + codCAEN + '\'' +
                ", esteSuspendata=" + esteSuspendata +
                '}';
    }
}
