package ro.ase.semdam_1117;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String[] departamente = {"Marketing", "Resurse Umane", "TIC"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                departamente);
        Spinner spinner = findViewById(R.id.spinnerDepartament);
        spinner.setAdapter(adapter);

        EditText etNume = findViewById(R.id.editTextNume);
        EditText etDataAngajarii = findViewById(R.id.editTextDate);
        EditText etSalariu = findViewById(R.id.editTextSalariu);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        Button btnAdauga = findViewById(R.id.btnAdauga);
        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etNume.getText().toString().isEmpty())
                    etNume.setError("Introduceti numele!");
                else
                    if(etDataAngajarii.getText().toString().isEmpty())
                        etDataAngajarii.setError("Introduceti data!");
                    else
                        if(etSalariu.getText().toString().isEmpty())
                            etSalariu.setError("Introduceti salariul!");
                        else
                        {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy",
                                    Locale.US);
                            try {
                                sdf.parse(etDataAngajarii.getText().toString());
                                Date dataAngajarii = new Date(etDataAngajarii.getText().toString());
                                String nume = etNume.getText().toString();
                                float salariu = Float.parseFloat(etSalariu.getText().toString());
                                String departament = spinner.getSelectedItem().toString();
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                boolean areContractRemote = false;
                                if(radioButton.getText().equals("DA"))
                                    areContractRemote = true;

                                Angajat angajat = new Angajat(nume, dataAngajarii, salariu, departament, areContractRemote);
                                Toast.makeText(getApplicationContext(), angajat.toString(), Toast.LENGTH_LONG).show();

                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                            catch (Exception ex)
                            {
                                Toast.makeText(getApplicationContext(),
                                        ex.getMessage(),Toast.LENGTH_LONG).show();
                            }

                        }
            }
        });
    }
}