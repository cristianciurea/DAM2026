package ro.ase.semdam_1117;

import java.util.Date;

public class Angajat {

    private String nume;
    private Date dataAngajarii;
    private float salariu;
    private String departament; //Marketing, Resurse Umane, TIC
    private boolean areContractRemote; //DA - true, NU - false

    public Angajat(String nume, Date dataAngajarii, float salariu, String departament, boolean areContractRemote) {
        this.nume = nume;
        this.dataAngajarii = dataAngajarii;
        this.salariu = salariu;
        this.departament = departament;
        this.areContractRemote = areContractRemote;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public Date getDataAngajarii() {
        return dataAngajarii;
    }

    public void setDataAngajarii(Date dataAngajarii) {
        this.dataAngajarii = dataAngajarii;
    }

    public float getSalariu() {
        return salariu;
    }

    public void setSalariu(float salariu) {
        this.salariu = salariu;
    }

    public String getDepartament() {
        return departament;
    }

    public void setDepartament(String departament) {
        this.departament = departament;
    }

    public boolean isAreContractRemote() {
        return areContractRemote;
    }

    public void setAreContractRemote(boolean areContractRemote) {
        this.areContractRemote = areContractRemote;
    }

    @Override
    public String toString() {
        return "Angajat{" +
                "nume='" + nume + '\'' +
                ", dataAngajarii=" + dataAngajarii +
                ", salariu=" + salariu +
                ", departament='" + departament + '\'' +
                ", areContractRemote=" + areContractRemote +
                '}';
    }
}
