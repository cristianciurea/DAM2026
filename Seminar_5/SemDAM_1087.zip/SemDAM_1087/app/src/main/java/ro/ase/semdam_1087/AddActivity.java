package ro.ase.semdam_1087;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_MASINA = "addMasina";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();

        String[] motorizari = {"Benzina", "Diesel", "Hybrid", "Electric"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                motorizari);
        Spinner spinnerMotorizare = findViewById(R.id.spinnerMotorizare);
        spinnerMotorizare.setAdapter(adapter);

        EditText etMarca = findViewById(R.id.editTextMarca);
        EditText etDataFabricatiei = findViewById(R.id.editTextDate);
        EditText etPret = findViewById(R.id.editTextPret);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        Button btnAdauga = findViewById(R.id.btnAdd);

        if(intent.hasExtra(MainActivity.EDIT_MASINA))
        {
            Masina masina = (Masina) intent.getSerializableExtra(MainActivity.EDIT_MASINA);
            etMarca.setText(masina.getMarca());
            etDataFabricatiei.setText(new SimpleDateFormat("MM/dd/yyyy",
                    Locale.US).format(masina.getDataFabricatiei()));
            etPret.setText(String.valueOf(masina.getPret()));
            ArrayAdapter<String> adapter1 = (ArrayAdapter<String>) spinnerMotorizare.getAdapter();
            for(int i=0;i<adapter1.getCount();i++)
                if(adapter1.getItem(i).equals(masina.getMotorizare()))
                {
                    spinnerMotorizare.setSelection(i);
                    break;
                }
            if(masina.isAreRCA()==true)
                radioGroup.check(R.id.radioButtonDA);
            else
                radioGroup.check(R.id.radioButtonNU);
        }

        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etMarca.getText().toString().isEmpty())
                    etMarca.setError("Introduceti marca!");
                else
                    if(etDataFabricatiei.getText().toString().isEmpty())
                        etDataFabricatiei.setError("Introduceti data!");
                    else
                        if(etPret.getText().toString().isEmpty())
                            etPret.setError("Introduceti pretul!");
                        else
                        {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                            try {
                                sdf.parse(etDataFabricatiei.getText().toString());
                                Date dataFabricatiei = new Date(etDataFabricatiei.getText().toString());

                                String marca = etMarca.getText().toString();
                                float pret = Float.parseFloat(etPret.getText().toString());
                                String motorizare = spinnerMotorizare.getSelectedItem().toString();
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                boolean areRCA = false;
                                if(radioButton.getText().toString().equals("DA"))
                                    areRCA = true;

                                Masina masina = new Masina(marca, dataFabricatiei, pret, motorizare, areRCA);
                                /*Toast.makeText(getApplicationContext(), masina.toString(),
                                        Toast.LENGTH_LONG).show();*/
                                intent.putExtra(ADD_MASINA, masina);
                                setResult(RESULT_OK, intent);
                                finish();
                                /*Intent intent1 = new Intent(getApplicationContext(), AfisareActivity.class);
                                intent1.putExtra(ADD_MASINA, masina);
                                startActivity(intent1);*/

                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                            catch (Exception e)
                            {
                                Log.e("AddActivity", e.getMessage().toString());
                                Toast.makeText(getApplicationContext(), e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }
}