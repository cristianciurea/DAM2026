package ro.ase.semdam_1087;

import java.util.Date;

public class Masina {

    private String marca;
    private Date dataFabricatiei;
    private float pret;
    private String motorizare; //Benzina, Diesel, Hybrid, Electric
    private boolean areRCA; //DA - true, NU - false

    public Masina(String marca, Date dataFabricatiei, float pret, String motorizare, boolean areRCA) {
        this.marca = marca;
        this.dataFabricatiei = dataFabricatiei;
        this.pret = pret;
        this.motorizare = motorizare;
        this.areRCA = areRCA;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Date getDataFabricatiei() {
        return dataFabricatiei;
    }

    public void setDataFabricatiei(Date dataFabricatiei) {
        this.dataFabricatiei = dataFabricatiei;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String getMotorizare() {
        return motorizare;
    }

    public void setMotorizare(String motorizare) {
        this.motorizare = motorizare;
    }

    public boolean isAreRCA() {
        return areRCA;
    }

    public void setAreRCA(boolean areRCA) {
        this.areRCA = areRCA;
    }

    @Override
    public String toString() {
        return "Masina{" +
                "marca='" + marca + '\'' +
                ", dataFabricatiei=" + dataFabricatiei +
                ", pret=" + pret +
                ", motorizare='" + motorizare + '\'' +
                ", areRCA=" + areRCA +
                '}';
    }
}
