package ro.ase.semdam_1085;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    public ListView listView;

    List<Student> listaStud = new ArrayList<>();

    public static final int REQUEST_CODE_ADD = 100;

    public static final int REQUEST_CODE_EDIT = 200;

    public static final String EDIT_STUDENT = "editStudent";

    public int poz;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Student student = listaStud.get(position);

                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirmare stergere")
                        .setMessage("Doriti sa stergeti?")
                        .setNegativeButton("NU", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        })
                        .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                executor.execute(() -> {
                                    AppDatabase.getInstance(MainActivity.this).studentDao().delete(student);
                                    List<Student> dinDb =
                                            AppDatabase.getInstance(MainActivity.this).studentDao().getAll();
                                    mainHandler.post(() -> afiseazaLista(dinDb));
                                });
                                dialogInterface.cancel();
                            }
                        })
                        .create();

                dialog.show();

                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                poz = position;
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                intent.putExtra(EDIT_STUDENT, listaStud.get(position));
                startActivityForResult(intent, REQUEST_CODE_EDIT);
            }
        });

        executor.execute(() -> {
            List<Student> dinDb = AppDatabase.getInstance(this).studentDao().getAll();
            mainHandler.post(() -> afiseazaLista(dinDb));
        });
    }

    private void afiseazaLista(List<Student> studenti) {
        listaStud.clear();
        listaStud.addAll(studenti);
        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), R.layout.elem_listview,
                listaStud, getLayoutInflater()) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                Student student1 = listaStud.get(position);

                TextView tvMedie = view.findViewById(R.id.tvMedie);
                if (student1.getMedie() >= 5)
                    tvMedie.setTextColor(Color.GREEN);
                else
                    tvMedie.setTextColor(Color.RED);

                return view;
            }
        };
        listView.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD && resultCode == RESULT_OK && data != null) {
            Student student = (Student) data.getSerializableExtra(AddActivity.ADD_STUDENT);
            if (student != null) {
                executor.execute(() -> {
                    StudentDao dao = AppDatabase.getInstance(this).studentDao();
                    long id = dao.insert(student);
                    student.setId(id);
                    List<Student> dinDb = dao.getAll();
                    mainHandler.post(() -> afiseazaLista(dinDb));
                });
            }
        } else if (requestCode == REQUEST_CODE_EDIT && resultCode == RESULT_OK && data != null) {
            Student student = (Student) data.getSerializableExtra(AddActivity.ADD_STUDENT);
            if (student != null) {
                executor.execute(() -> {
                    StudentDao dao = AppDatabase.getInstance(this).studentDao();
                    dao.update(student);
                    List<Student> dinDb = dao.getAll();
                    mainHandler.post(() -> afiseazaLista(dinDb));
                });
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.meniu_principal, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.optiune1) {
            Intent intent = new Intent(this, BNRActivity.class);
            startActivity(intent);

            return true;
        } else if (item.getItemId() == R.id.optiune2) {
            ExtractXML extractXML = new ExtractXML() {
                @Override
                protected void onPostExecute(InputStream inputStream) {
                    listaStud.addAll(studentList);
                    afiseazaLista(new ArrayList<>(listaStud));
                }
            };
            try {
                extractXML.execute(new URL("https://pastebin.com/raw/v0diWZJG"));
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
            return true;
        } else if (item.getItemId() == R.id.optiune3) {
            ExtractJSON extractJSON = new ExtractJSON() {
                ProgressDialog progressDialog;

                @Override
                protected void onPreExecute() {
                    progressDialog = new ProgressDialog(MainActivity.this);
                    progressDialog.setMessage("Please wait...");
                    progressDialog.show();
                }

                @Override
                protected void onPostExecute(String s) {
                    progressDialog.cancel();

                    listaStud.addAll(this.studentListJSON);
                    afiseazaLista(new ArrayList<>(listaStud));
                }
            };
            try {
                extractJSON.execute(new URL("https://pastebin.com/raw/Z8ajeUhk"));
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
            return true;
        } else if (item.getItemId() == R.id.optiune4) {
            //TO DO
            return true;
        }

        return false;
    }
}
