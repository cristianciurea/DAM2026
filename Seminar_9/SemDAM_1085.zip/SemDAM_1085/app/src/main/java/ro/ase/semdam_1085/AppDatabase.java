package ro.ase.semdam_1085;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {Student.class}, version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class AppDatabase extends RoomDatabase {

    public abstract StudentDao studentDao();

    private static volatile AppDatabase instanta;

    public static AppDatabase getInstance(Context context) {
        if (instanta == null) {
            synchronized (AppDatabase.class) {
                if (instanta == null) {
                    instanta = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "semdam_1085.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return instanta;
    }
}
