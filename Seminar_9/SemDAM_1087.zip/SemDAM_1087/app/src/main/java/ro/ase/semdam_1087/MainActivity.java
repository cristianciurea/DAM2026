package ro.ase.semdam_1087;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    public ListView listView;

    List<Masina> listaMasini = new ArrayList<>();

    public static final int REQUEST_CODE_ADD = 100;

    public static final int REQUEST_CODE_EDIT = 200;

    public static final String EDIT_MASINA = "editMasina";

    public int poz;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listViewMasini);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Masina masina = listaMasini.get(position);

                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirmare stergere")
                        .setMessage("Doriti sa stergeti?")
                        .setNegativeButton("NU", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        })
                        .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                executor.execute(() -> {
                                    AppDatabase.getInstance(MainActivity.this).masinaDao().delete(masina);
                                    List<Masina> dinDb =
                                            AppDatabase.getInstance(MainActivity.this).masinaDao().getAll();
                                    mainHandler.post(() -> afiseazaLista(dinDb));
                                });
                                dialogInterface.cancel();
                            }
                        })
                        .create();

                dialog.show();

                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                poz = position;
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                intent.putExtra(EDIT_MASINA, listaMasini.get(position));
                startActivityForResult(intent, REQUEST_CODE_EDIT);
            }
        });

        executor.execute(() -> {
            List<Masina> dinDb = AppDatabase.getInstance(this).masinaDao().getAll();
            mainHandler.post(() -> afiseazaLista(dinDb));
        });
    }

    private void afiseazaLista(List<Masina> masini) {
        listaMasini.clear();
        listaMasini.addAll(masini);
        CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                R.layout.elem_listview, listaMasini, getLayoutInflater()) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                Masina masina1 = listaMasini.get(position);

                TextView tvRCA = view.findViewById(R.id.tvRCA);
                if (masina1.isAreRCA())
                    tvRCA.setTextColor(Color.GREEN);
                else
                    tvRCA.setTextColor(Color.RED);

                return view;
            }
        };
        listView.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD && resultCode == RESULT_OK && data != null) {
            Masina masina = (Masina) data.getSerializableExtra(AddActivity.ADD_MASINA);
            if (masina != null) {
                executor.execute(() -> {
                    MasinaDao dao = AppDatabase.getInstance(this).masinaDao();
                    long id = dao.insert(masina);
                    masina.setId(id);
                    List<Masina> dinDb = dao.getAll();
                    mainHandler.post(() -> afiseazaLista(dinDb));
                });
            }
        } else if (requestCode == REQUEST_CODE_EDIT && resultCode == RESULT_OK && data != null) {
            Masina masina = (Masina) data.getSerializableExtra(AddActivity.ADD_MASINA);
            if (masina != null) {
                executor.execute(() -> {
                    MasinaDao dao = AppDatabase.getInstance(this).masinaDao();
                    dao.update(masina);
                    List<Masina> dinDb = dao.getAll();
                    mainHandler.post(() -> afiseazaLista(dinDb));
                });
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.meniu_principal, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.optiune1) {
            Intent intent = new Intent(this, BNRActivity.class);
            startActivity(intent);

            return true;
        } else if (item.getItemId() == R.id.optiune2) {
            ExtractXML extractXML = new ExtractXML() {
                @Override
                protected void onPostExecute(InputStream inputStream) {
                    listaMasini.addAll(masinaList);
                    afiseazaLista(new ArrayList<>(listaMasini));
                }
            };
            try {
                extractXML.execute(new URL("https://pastebin.com/raw/csbkacXU"));
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
            return true;
        } else if (item.getItemId() == R.id.optiune3) {
            ExtractJSON extractJSON = new ExtractJSON() {
                ProgressDialog progressDialog;

                @Override
                protected void onPreExecute() {
                    progressDialog = new ProgressDialog(MainActivity.this);
                    progressDialog.setMessage("Please wait...");
                    progressDialog.show();
                }

                @Override
                protected void onPostExecute(String s) {
                    listaMasini.addAll(masinaListJSON);
                    progressDialog.cancel();
                    afiseazaLista(new ArrayList<>(listaMasini));
                }
            };
            try {
                extractJSON.execute(new URL("https://pastebin.com/raw/KH8Fpyfv"));
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
            return true;
        } else if (item.getItemId() == R.id.optiune4) {
            //TO DO
            return true;
        }

        return false;
    }
}
