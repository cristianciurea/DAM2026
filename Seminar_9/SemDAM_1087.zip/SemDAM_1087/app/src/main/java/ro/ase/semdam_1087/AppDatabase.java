package ro.ase.semdam_1087;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {Masina.class}, version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class AppDatabase extends RoomDatabase {

    public abstract MasinaDao masinaDao();

    private static volatile AppDatabase instanta;

    public static AppDatabase getInstance(Context context) {
        if (instanta == null) {
            synchronized (AppDatabase.class) {
                if (instanta == null) {
                    instanta = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "semdam_1087.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return instanta;
    }
}
