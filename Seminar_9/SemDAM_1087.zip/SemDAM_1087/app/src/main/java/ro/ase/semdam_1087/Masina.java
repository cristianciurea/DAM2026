package ro.ase.semdam_1087;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.util.Date;

@Entity(tableName = "masini")
public class Masina implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String marca;
    private Date dataFabricatiei;
    private float pret;
    private String motorizare; //Benzina, Diesel, Hybrid, Electric
    private boolean areRCA; //DA - true, NU - false

    @Ignore
    public Masina() {
    }

    @Ignore
    public Masina(String marca, Date dataFabricatiei, float pret, String motorizare, boolean areRCA) {
        this(0, marca, dataFabricatiei, pret, motorizare, areRCA);
    }

    public Masina(long id, String marca, Date dataFabricatiei, float pret, String motorizare, boolean areRCA) {
        this.id = id;
        this.marca = marca;
        this.dataFabricatiei = dataFabricatiei;
        this.pret = pret;
        this.motorizare = motorizare;
        this.areRCA = areRCA;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Date getDataFabricatiei() {
        return dataFabricatiei;
    }

    public void setDataFabricatiei(Date dataFabricatiei) {
        this.dataFabricatiei = dataFabricatiei;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String getMotorizare() {
        return motorizare;
    }

    public void setMotorizare(String motorizare) {
        this.motorizare = motorizare;
    }

    public boolean isAreRCA() {
        return areRCA;
    }

    public void setAreRCA(boolean areRCA) {
        this.areRCA = areRCA;
    }

    @Override
    public String toString() {
        return "Masina{" +
                "id=" + id +
                ", marca='" + marca + '\'' +
                ", dataFabricatiei=" + dataFabricatiei +
                ", pret=" + pret +
                ", motorizare='" + motorizare + '\'' +
                ", areRCA=" + areRCA +
                '}';
    }
}
