package ro.ase.semdam_1087;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface MasinaDao {

    @Query("SELECT * FROM masini")
    List<Masina> getAll();

    @Insert
    long insert(Masina masina);

    @Update
    void update(Masina masina);

    @Delete
    void delete(Masina masina);
}
